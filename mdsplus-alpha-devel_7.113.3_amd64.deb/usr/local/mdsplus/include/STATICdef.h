#ifndef __STATICdef
#define STATIC_ROUTINE static
#define STATIC_CONSTANT static
#define STATIC_THREADSAFE static
#define __STATICdef
#endif
