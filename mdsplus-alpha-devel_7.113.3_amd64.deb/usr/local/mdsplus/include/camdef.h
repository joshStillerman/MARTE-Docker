#ifndef __CAMDEF
#define __CAMDEF

#include <camshr_messages.h>
#define CamXE        0
#define CamQE        0
#define CamQDC       1
#define CamQNE       2
#define CamXI        4

#endif
